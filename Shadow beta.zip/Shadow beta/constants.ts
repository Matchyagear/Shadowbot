
export const YOUR_INITIAL_PICKS = ["NVDA", "MSFT", "AAPL", "GOOGL", "META", "TSLA", "VRT"];
